import bigPicture.BigPicture;

public class MainApp {

    public static void main(String[] args) {
        BigPicture bigPicture = new BigPicture();
        bigPicture.sunset();
    }
}
